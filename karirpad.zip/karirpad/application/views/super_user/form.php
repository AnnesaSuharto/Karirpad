<div class="main-wrapper">
    <div class="row">
        <div class="col-md-12 col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Input Barang</h5>
                    <form method="POST" action="<?= base_url('super_user/form') ?>" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label for="formFile" class="form-label">Gambar Barang</label>
                            <input type="hidden" name="old_image" value="<?php echo $data->gambar_barang;  ?>">
                            <input class="form-control" type="file" id="" name="gambar_barang" value="<?= $data->gambar_barang; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Nama Barang</label>
                            <input type="text" class="form-control" id="" name="nama_barang" value="<?= $data->nama_barang ?>">

                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Kategori</label>
                            <input type="text" class="form-control" id="" name="kategori" value="<?= $data->kategori ?>">

                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Harga</label>
                            <input type="text" class="form-control" id="" name="harga" value="<?= $data->harga ?>">

                        </div>
                        <input type="text" hidden id="id_barang" name="id_barang" value="<?php echo $data->id_barang; ?>">
                        <input type="text" hidden id="submitBarang" name="submitBarang" value="submitBarang">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>