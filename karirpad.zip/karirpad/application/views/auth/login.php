<div class="container">
    <div class="row justify-content-md-center">
        <div class="col-md-12 col-lg-4">
            <div class="card login-box-container">
                <div class="card-body">
                    <div class="authent-logo">
                        <a href="#">Karirpad</a>
                    </div>
                    <div class="authent-text">
                        <p>Welcome to Karirpad</p>
                        <p>Please Sign-in to your account.</p>
                    </div>

                    <form method="POST" action="<?= base_url('auth'); ?>">
                        <div class="mb-3">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email Address" value="<?= set_value('email'); ?>">
                                <?= form_error('email', '<small class="text-danger pl-3">', '</small>') ?>
                                <label for="">Email address</label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="form-floating">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                                <?= form_error('password', '<small class="text-danger pl-3">', '</small>') ?>
                                <label for=" ">Password</label>
                            </div>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-info m-b-xs">Sign In</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>