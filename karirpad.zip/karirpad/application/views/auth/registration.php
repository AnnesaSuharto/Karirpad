<body class="login-page">

    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-md-12 col-lg-4">
                <div class="card login-box-container">
                    <div class="card-body">
                        <div class="authent-logo">
                            <a href="#">Neo</a>
                        </div>
                        <div class="authent-text">
                            <p>Welcome to Neo</p>
                            <p>Enter your details to create your account</p>
                        </div>

                        <form method="POST" action="<?= base_url('auth/registration'); ?>">
                            <div class="mb-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Fullname">
                                    <?php echo form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                                    <label for="floatingInput">Fullname</label>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="email" name="email" placeholder="name@example.com">
                                    <?php echo form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
                                    <label for="floatingInput">Email address</label>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="form-floating">
                                    <input type="password" class="form-control" id="password1" name="password1" placeholder="Password">
                                    <?php echo form_error('password1', '<small class="text-danger pl-3">', '</small>'); ?>
                                    <label for="floatingPassword">Password</label>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="form-floating">
                                    <input type="password" class="form-control" id="password2" name="password2" placeholder="Confirm Password">
                                    <?php echo form_error('password2', '<small class="text-danger pl-3">', '</small>'); ?>
                                    <label for="floatingPassword">Confirm Password</label>
                                </div>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                <label class="form-check-label" for="exampleCheck1">I agree the <a href="#">Terms and Conditions</a></label>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary m-b-xs">Register</button>
                            </div>
                        </form>
                        <div class="authent-login">
                            <p>Already have an account? <a href="login.html">Sign in</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>