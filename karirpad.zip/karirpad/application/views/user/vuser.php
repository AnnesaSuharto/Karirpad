            <div class="main-wrapper">
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Barang Penjualan</h5>
                                <!-- <a href="<?= base_url('user/form/0') ?>" class="btn btn-outline-primary m-b-xs">New Data</a> -->
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Foto Barang</th>
                                            <th scope="col">Nama Barang</th>
                                            <th scope="col">Kategori</th>
                                            <th scope="col">Harga</th>
                                            <th scope="col">Diskon</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 1;
                                        foreach ($data as $row) {
                                        ?>
                                            <tr>
                                                <td><?= $no ?></td>
                                                <td><?php echo "<img src='assets/images/gambar/$row[gambar_barang]' width='70' height='90' />"; ?></td>
                                                <td><?= $row['nama_barang']; ?></td>
                                                <td><?= $row['kategori'] ?></td>
                                                <td><?= $row['harga'] ?></td>
                                                <td><?= $row['diskon'] ?></td>
                                            </tr>
                                        <?php
                                            $no++;
                                        }
                                        ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            </div>

            </div>

            <div class="activity-sidebar-overlay"></div>
            <div class="activity-sidebar">
                <a href="#" id="activity-sidebar-close"><i class="material-icons">close</i></a>
                <div class="activity-header">
                    <h5>Activity Logs</h5>
                </div>
                <div class="activity-body">
                    <ul class="activity-list list-unstyled">
                        <li class="activity-item">
                            <div class="activity-icon"><i class="material-icons">add</i></div>
                            <div class="activity-text">Ann Green uploaded new item
                                <span>This item has to be reviewed, moderators will check it soon.</span>
                            </div>
                            <div class="activity-helper">45min ago</div>
                        </li>
                        <li class="activity-item activity-info">
                            <div class="activity-icon"><i class="material-icons">code</i></div>
                            <div class="activity-text">John Doe made changes to create-invoice.js
                                <span>57 lines of code added, 0 removals, 0 errors, 6 warnings</span>
                            </div>
                            <div class="activity-helper">3h ago</div>
                        </li>
                        <li class="activity-item activity-danger">
                            <div class="activity-icon"><i class="material-icons">error_outline</i></div>
                            <div class="activity-text">Can't retrieve data from server
                                <span>Server is not responding, please contact provider</span>
                            </div>
                            <div class="activity-helper">6h ago</div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon"><i class="material-icons">done</i></div>
                            <div class="activity-text">Files Uploaded
                                <span>2 new files uploaded</span>
                                <div class="mail-attachment-files">
                                    <div class="card">
                                        <img src="<?= base_url('assets/') ?>images/bg-1.png" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title">image.jpg</h5>
                                            <p class="card-text text-secondary">305 KB</p>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <img src="<?= base_url('assets/') ?>images/card-bg.png" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title">image2.jpg</h5>
                                            <p class="card-text text-secondary">400 KB</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="activity-helper">8h ago</div>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="search-results">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="search-results-header">
                                <h5>Search Results</h5>
                                <a href="#" id="closeSearch"><i class="material-icons">close</i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>