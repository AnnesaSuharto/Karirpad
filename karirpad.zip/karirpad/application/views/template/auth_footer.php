<!-- Javascripts -->
<script src="<?= base_url('assets/') ?>plugins/jquery/jquery-3.4.1.min.js"></script>
<script src="https://unpkg.com/@popperjs/core@2"></script>
<script src="<?= base_url('assets/') ?>plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/feather-icons"></script>
<script src="<?= base_url('assets/') ?>plugins/perfectscroll/perfect-scrollbar.min.js"></script>
<script src="<?= base_url('assets/') ?>plugins/pace/pace.min.js"></script>
<script src="<?= base_url('assets/') ?>js/main.min.js"></script>

</body>

</html>