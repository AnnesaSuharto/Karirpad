<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        // $this->load->library('session');
        $this->load->model('mbarang');
    }

    public function index()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['data'] = $this->mbarang->get_list();

        for ($i = 0; $i < count($data['data']); $i++) {
            $harga =  $data['data'][$i]['harga'];
            if ($harga > 40000) {
                $data['data'][$i]['diskon'] = 10 / 100 * $harga;
            } elseif ($harga > 20000 && $harga <= 40000) {
                $data['data'][$i]['diskon'] = 5 / 100 * $harga;
            } else {
                $data['data'][$i]['diskon'] = 0;
            }
        }
        $this->load->view('template/header');
        $this->load->view('user/vuser', $data);
        $this->load->view('template/footer');
    }
}
