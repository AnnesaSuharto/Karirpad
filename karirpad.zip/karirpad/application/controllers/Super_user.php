<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Super_user extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        // is_logged_in();
        $this->load->model('mbarang');
    }

    public function index()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['data'] = $this->mbarang->get_list();

        for ($i = 0; $i < count($data['data']); $i++) {
            $harga =  $data['data'][$i]['harga'];
            if ($harga > 40000) {
                $data['data'][$i]['diskon'] = 10 / 100 * $harga;
            } elseif ($harga > 20000 && $harga <= 40000) {
                $data['data'][$i]['diskon'] = 5 / 100 * $harga;
            } else {
                $data['data'][$i]['diskon'] = 0;
            }
        }
        $data['title'] = 'Tampil Data | Karirpad';
        $this->load->view('template/header', $data);
        $this->load->view('super_user/vsuper_user', $data);
        $this->load->view('template/footer');
    }

    public function form($id = 0, $dari = NULL)
    {
        if ($this->input->post('submitBarang')) {
            $input = $this->input->post(NULL, TRUE);

            extract($input);

            if (isset($id_barang)) {
                $idbarang = $id_barang;
            }

            if (!empty($_FILES["gambar_barang"]["name"])) {
                $dataItem = array(
                    'gambar_barang' => $this->_uploadImage(),
                    'nama_barang' => $nama_barang,
                    'kategori' => $kategori,
                    'harga' => $harga
                );
            } else {
                $dataItem = array(
                    'gambar_barang' => $old_image,
                    'nama_barang' => $nama_barang,
                    'kategori' => $kategori,
                    'harga' => $harga
                );
            }


            if ($branchId = $this->save($dataItem, $idbarang)) {

                redirect("super_user");
            }
        } else {
            $obj = new stdClass();
            $obj->id_barang = $id;
            $obj->gambar_barang = '';
            $obj->nama_barang = '';
            $obj->kategori = '';
            $obj->harga = '';

            // Ubah
            if ($id != 0) {

                $obj = $this->mbarang->get_by_id($id);
            }

            $data['data'] = $obj;
            $data['title'] = 'Form Barang | Karirpad';
            $this->load->view('template/header');
            $this->load->view('super_user/form', $data);
            $this->load->view('template/footer');
        }
    }

    private function _uploadImage()
    {
        $config['upload_path'] = './assets/images/gambar/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg|pdf';

        $config['overwrite'] = false;
        $config['max_size'] = 1024; // 1MB

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('gambar_barang')) {
            return $this->upload->data("file_name");
        }

        return "default.jpg";
    }

    public function save($data, $idBarang = 0)
    {
        return $this->mbarang->saveData($data, $idBarang);
    }

    public function delete($id)
    {
        if ($this->mbarang->delete($id)) {
            redirect('super_user');
        }
    }
}
