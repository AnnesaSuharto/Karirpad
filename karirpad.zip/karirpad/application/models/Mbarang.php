<?php

class Mbarang extends CI_Model
{

    //put your code here
    function get_list()
    {
        $query = $this->db->get('barang');
        return $query->result_array();
    }

    function get_by_id($id)
    {
        $this->db->where('id_barang', $id);
        $query = $this->db->get('barang');
        return $query->row();
    }

    public function saveData($data, $idBarang = 0)
    {
        if ($idBarang != 0) {

            $this->db->where('id_barang', $idBarang);

            if ($this->db->update('barang', $data)) {
                $this->session->set_userdata('tipeNotif', 'successEdit');
                return TRUE;
            } else {
                $this->session->set_userdata('tipeNotif', 'error');
                return FALSE;
            }
        } else {

            if ($this->db->insert('barang', $data)) {
                $this->session->set_userdata('tipeNotif', 'successAdd');
                return $this->db->insert_id();
            } else {
                $this->session->set_userdata('tipeNotif', 'error');
                return FALSE;
            }
        }
    }
    public function delete($id)
    {
        if ($this->db->delete('barang', array('id_barang' => $id))) {
            $this->session->set_userdata('tipeNotif', 'successDelete');
            return TRUE;
        } else {
            $this->session->set_userdata('tipeNotif', 'error');
            return FALSE;
        }
    }
}
